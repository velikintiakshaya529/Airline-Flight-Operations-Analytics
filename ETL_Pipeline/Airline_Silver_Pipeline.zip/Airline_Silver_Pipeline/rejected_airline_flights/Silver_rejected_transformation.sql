
CREATE OR REFRESH MATERIALIZED VIEW rejected_airline_flights
AS

SELECT
    *,
    CASE
        WHEN passengers > seat_capacity
            THEN 'Passengers exceed seat capacity'

        WHEN passengers < 0
            THEN 'Negative passenger count'

        WHEN avg_fare < 0
            THEN 'Negative average fare'

        ELSE 'Unknown data issue'
    END AS rejection_reason

FROM workspace.default.bronze_airline_flights

WHERE passengers > seat_capacity
   OR passengers < 0
   OR avg_fare < 0;
