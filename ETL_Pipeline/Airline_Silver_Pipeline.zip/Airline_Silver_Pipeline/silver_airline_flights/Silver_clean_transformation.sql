
CREATE OR REFRESH MATERIALIZED VIEW silver_airline_flights
AS

WITH cleaned AS (
    SELECT
        flight_id,
        flight_number,
        COALESCE(INITCAP(TRIM(airline)), 'Unknown') AS airline,
        aircraft_id,
        aircraft_type,
        flight_date,
        day_of_week,
        INITCAP(TRIM(origin_city)) AS origin_city,
        INITCAP(TRIM(destination_city)) AS destination_city,
        INITCAP(TRIM(origin_region)) AS origin_region,
        distance_km,
        scheduled_departure,
        actual_departure,

        COALESCE(
            delay_minutes,
            TIMESTAMPDIFF(
                MINUTE,
                scheduled_departure,
                actual_departure
            )
        ) AS delay_minutes,

        COALESCE(
            NULLIF(TRIM(delay_reason), ''),
            'Unknown'
        ) AS delay_reason,

        seat_capacity,
        passengers,
        avg_fare,

        COALESCE(
            ticket_revenue,
            passengers * avg_fare
        ) AS ticket_revenue,

        fuel_cost,

        ROW_NUMBER() OVER (
            PARTITION BY flight_id
            ORDER BY flight_date
        ) AS row_num

    FROM workspace.default.bronze_airline_flights
)

SELECT
    flight_id,
    flight_number,
    airline,
    aircraft_id,
    aircraft_type,
    flight_date,
    day_of_week,
    origin_city,
    destination_city,
    origin_region,
    distance_km,
    scheduled_departure,
    actual_departure,
    delay_minutes,
    delay_reason,
    seat_capacity,
    passengers,
    avg_fare,
    ticket_revenue,
    fuel_cost,

    CASE
        WHEN delay_minutes <= 15 THEN 'On Time'
        WHEN delay_minutes <= 60 THEN 'Minor Delay'
        ELSE 'Major Delay'
    END AS delay_category

FROM cleaned
WHERE row_num = 1
  AND passengers >= 0
  AND passengers <= seat_capacity
  AND avg_fare >= 0;
